#Para crear un paquete hay que crear un archivo con este nombre "__init__.py"
#Con este "__init__.py" podremos acceder a los módulos del directorio para importarlos, de otra forma no.

